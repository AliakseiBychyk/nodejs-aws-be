
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'aleksbyczyk',
  applicationName: 'aleks-rs-app-app',
  appUid: 'R11yzQxDNq1tQHGbwj',
  orgUid: 'b3da5a36-6209-4216-aaa8-e35b3c1d6eac',
  deploymentUid: 'bca310ca-17f6-4dc4-86bf-d6458654a01b',
  serviceName: 'weather-info-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'weather-info-service-dev-getWeatherInfo', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getWeatherInfo, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}