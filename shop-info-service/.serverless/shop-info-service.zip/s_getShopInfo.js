
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'aleksbyczyk',
  applicationName: 'aleks-rs-app-app',
  appUid: 'R11yzQxDNq1tQHGbwj',
  orgUid: 'b3da5a36-6209-4216-aaa8-e35b3c1d6eac',
  deploymentUid: 'c0d9764b-f846-43fa-bde3-ad6035c081f3',
  serviceName: 'shop-info-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shop-info-service-dev-getShopInfo', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getShopInfo, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}